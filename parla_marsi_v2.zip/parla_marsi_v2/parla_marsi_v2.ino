/*
 * Yazan: Esra Pınar YUSUF
 * Tarih: 11.10.2025 (Kodun yeniden düzenlenmesi 28.10.2025)
 * Proje: Buzzer ile Parla Marşı (100. Yıl Marşı)
 * * Bu kod, orijinal kodun değişkenler ve diziler kullanılarak
 * yeniden düzenlenmiş (refactor edilmiş) halidir.
 */

// --- Nota Frekansları için Değişken Tanımlamaları ---
// Notaları frekans değerleri yerine isimleriyle kullanmak kodu daha okunaklı kılar.
#define NOTE_REST 0    // Sessizlik (Es)
#define NOTE_D4   294  // Re
#define NOTE_E4   330  // Mi
#define NOTE_F4   349  // Fa
#define NOTE_G4   392  // Sol
#define NOTE_GS4  415  // Sol diyez
#define NOTE_A4   440  // La
#define NOTE_B4   494  // Si
#define NOTE_C5   523  // Do (ince)
#define NOTE_D5   587  // Re (ince)

// --- Değişkenler ---
int buzzerPin = 5; // Buzzer'ın bağlı olduğu pin

// 1. MARŞIN NOTA LİSTESİ (Dizisi)
// Orijinal koddaki tüm notalar sırasıyla buraya eklendi.
int melodyNotes[] = {
  // parla hilal ve yıldızım (8 nota + 1 es)
  NOTE_E4, NOTE_C5, NOTE_B4, NOTE_A4, NOTE_G4, NOTE_F4, NOTE_E4, NOTE_F4, NOTE_REST,
  
  // parla beyaz ve kırmızım (8 nota + 1 es)
  NOTE_C5, NOTE_B4, NOTE_C5, NOTE_D5, NOTE_C5, NOTE_B4, NOTE_A4, NOTE_G4, NOTE_REST,
  
  // türkün yolu (4 nota + 1 es)
  NOTE_E4, NOTE_F4, NOTE_E4, NOTE_D4, NOTE_REST,
  
  // cumhuriyet (4 nota + 1 es)
  NOTE_D4, NOTE_GS4, NOTE_F4, NOTE_E4, NOTE_REST,
  
  // parla 100 yaşındasın (7 nota + 1 es)
  NOTE_E4, NOTE_A4, NOTE_B4, NOTE_A4, NOTE_GS4, NOTE_A4, NOTE_B4, NOTE_REST
};

// 2. MARŞIN SÜRE LİSTESİ (Dizisi)
// Yukarıdaki her notaya karşılık gelen süre (milisaniye cinsinden).
int melodyDurations[] = {
  // parla hilal ve yıldızım
  500, 1000, 150, 300, 150, 300, 150, 1500, 300, // 300ms duraklama (es)
  
  // parla beyaz ve kırmızım
  500, 1000, 150, 300, 150, 300, 150, 1500, 300, // 300ms duraklama (es)
  
  // türkün yolu
  300, 700, 300, 500, 150, // 150ms duraklama (es)

  // cumhuriyet
  300, 700, 300, 500, 150, // 150ms duraklama (es)

  // parla 100 yaşındasın
  500, 1000, 300, 150, 300, 150, 700, 300 // 300ms duraklama (es)
};

void setup() {
  // Buzzer pinini ÇIKIŞ (OUTPUT) olarak ayarla
  pinMode(buzzerPin, OUTPUT);
}

void loop() {
  // Marştaki toplam nota sayısını hesapla
  // (Dizinin toplam boyutunu, bir elemanın boyutuna bölerek)
  int songLength = sizeof(melodyNotes) / sizeof(melodyNotes[0]);

  // Tüm marşı çalmak için notaları sırayla gezen döngü
  for (int i = 0; i < songLength; i++) {
    
    // Diziden mevcut notanın frekansını ve süresini al
    int currentFrequency = melodyNotes[i];
    int currentDuration = melodyDurations[i];

    // Notaların daha net ayrışması için çalma süresinden küçük bir pay ayır
    // Örneğin, %10'luk bir pay (0.10)
    // 500ms'lik nota: 450ms çalar, 50ms susar
    float notePauseFactor = 0.10; 
    int playDuration = currentDuration * (1.0 - notePauseFactor);
    int pauseDuration = currentDuration * notePauseFactor;

    // Notayı çal (eğer nota REST değilse)
    if (currentFrequency == NOTE_REST) {
      // Bu bir 'es' (sessizlik), sadece bekle
      delay(currentDuration); 
    } else {
      // Bu gerçek bir nota
      // 1. Notayı çal (tone fonksiyonu)
      tone(buzzerPin, currentFrequency);
      
      // 2. Notanın çalma süresi kadar bekle (tone sonrası delay)
      delay(playDuration);
      
      // 3. Notalar karışmasın diye sesi kapat
      noTone(buzzerPin);
      
      // 4. Bir sonraki notaya geçmeden önce kısa bir an sus
      delay(pauseDuration);
    }
  }

  // Marş bittikten sonra 3 saniye bekle ve loop() sayesinde tekrar başla
  delay(3000);
}